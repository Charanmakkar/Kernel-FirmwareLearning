@echo off
setlocal
pushd "%~dp0"
python build_reader.py
if errorlevel 1 (
  echo Reader refresh failed. Check that Python and the learning folder are available.
  pause
) else (
  start "" "%~dp0index.html"
)
popd
