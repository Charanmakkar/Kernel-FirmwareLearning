@echo off
setlocal
pushd "%~dp0"
echo Open http://127.0.0.1:8765 in your browser. Press Ctrl+C here to stop.
python serve.py
if errorlevel 1 pause
popd
